<template>
    <div>
        <router-view></router-view>
    </div>
 
</template>

<script setup>

</script>

<style lang="scss" scoped>
 #nprogress .bar {
     background: #F811B2 !important; //自定义颜色
  }
</style>