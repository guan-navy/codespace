# eslint的vue文件名报错
rules:{
    'vue/multi-word-component-names':0,//不再强制要求组件命名
  }

# scss使用
- 支持类名嵌套的写法
- 颜色变量的具体实现过程:
 1.在style中引入scss文件
 2.在style中使用变量


# elementplus的使用
需要再main.js中引入elementplus的样式文件
import 'element-plus/dist/index.css'

