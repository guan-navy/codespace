const config ={
    database:{
        DATABASE:'notebook',
        USERNAME:'root',
        PASSWORD:'3141592654mY',
        HOST:'localhost',
        PORT:3306
        
    }
    
}

module.exports = config