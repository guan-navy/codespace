const  formattedDate requires( './utils.js')
console.log(formattedDate(new Date()));